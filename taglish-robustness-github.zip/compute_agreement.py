#!/usr/bin/env python3
"""
compute_agreement.py
Reads the filled-in taglish_human_validation.xlsx and reports:
  - share of items each rater judged meaning-preserving (1)
  - share judged meaning-preserving by BOTH raters, overall and per operator
  - raw agreement and Cohen's kappa between the two raters
and prints a ready-to-paste LaTeX sentence for the Limitations paragraph.

Usage:  pip install openpyxl pandas
        python compute_agreement.py taglish_human_validation.xlsx
"""
import sys

import pandas as pd

OP_NAMES = {"P1_vowel_drop": "$T_1$", "P2_abbreviation": "$T_2$", "P3_leetspeak": "$T_3$",
            "P4_elongation": "$T_4$", "P5_funcword": "$T_5$", "P6_jejemon": "$T_6$"}


def read_sheet(path, name):
    df = pd.read_excel(path, sheet_name=name)
    col = [c for c in df.columns if str(c).startswith("Same meaning")][0]
    return df[["Item", col]].rename(columns={col: name})


def cohen_kappa(a, b):
    a, b = list(a), list(b)
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in (0, 1))
    return po, (po - pe) / (1 - pe) if pe < 1 else 1.0


def gwet_ac1(a, b):
    """Gwet's AC1: robust to the 'kappa paradox' when most items fall in one class."""
    a, b = list(a), list(b)
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    q = (sum(a) + sum(b)) / (2 * n)
    pe = 2 * q * (1 - q)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def main(path):
    r1, r2 = read_sheet(path, "Rater1"), read_sheet(path, "Rater2")
    key = pd.read_excel(path, sheet_name=[s for s in pd.ExcelFile(path).sheet_names
                                          if s.startswith("Key")][0])
    df = key.merge(r1, on="Item").merge(r2, on="Item")
    missing = df[df[["Rater1", "Rater2"]].isna().any(axis=1)]
    if len(missing):
        sys.exit(f"{len(missing)} items are not rated yet (items {missing.Item.tolist()[:10]}...). "
                 "Fill every row with 1 or 0 first.")
    df[["Rater1", "Rater2"]] = df[["Rater1", "Rater2"]].astype(int)
    bad = df[~df.Rater1.isin([0, 1]) | ~df.Rater2.isin([0, 1])]
    if len(bad):
        sys.exit(f"Only 1 or 0 allowed; check items {bad.Item.tolist()}")

    n = len(df)
    po, kappa = cohen_kappa(df.Rater1, df.Rater2)
    both = (df.Rater1 & df.Rater2).mean()
    print(f"Items: {n}")
    print(f"Rater 1 judged meaning preserved: {df.Rater1.mean():.1%}")
    print(f"Rater 2 judged meaning preserved: {df.Rater2.mean():.1%}")
    print(f"Both raters judged meaning preserved: {both:.1%}")
    ac1 = gwet_ac1(df.Rater1, df.Rater2)
    print(f"Raw agreement: {po:.1%}   Cohen's kappa: {kappa:.3f}   Gwet's AC1: {ac1:.3f}")
    print("\nPer operator (both raters = 1):")
    per = df.assign(both=df.Rater1 & df.Rater2).groupby("Operator")["both"].agg(["mean", "size"])
    for op, row in per.iterrows():
        print(f"  {op:16s} {row['mean']:.1%}  (n={int(row['size'])})")

    lowest = per["mean"].idxmin()
    print("\n--- LaTeX sentence for the Limitations paragraph ---")
    print(f"To check this claim, both authors, native speakers of Filipino, "
          f"independently rated {n} perturbed tweets (about {n // 6} per operator, "
          f"drawn at random from the test set at $r=0.3$) as meaning-preserving or not. "
          f"Both raters judged the meaning preserved for {100 * both:.1f}\\% of the items, "
          f"with raw agreement of {100 * po:.1f}\\%, Cohen's $\\kappa={kappa:.2f}$ and "
          f"Gwet's AC1 $={ac1:.2f}$; "
          f"the lowest rate was for {OP_NAMES.get(lowest, lowest)} "
          f"({100 * per.loc[lowest, 'mean']:.1f}\\%).")
    if kappa < 0.4 and po >= 0.85 and ac1 >= 0.6:
        print("\nNote: kappa is low only because almost all items are rated 1 (the 'kappa "
              "paradox'); raw agreement and Gwet's AC1 are high. Keep all three numbers in the "
              "paper, as in the sentence above.")
    elif kappa < 0.4:
        print("\nNote: agreement is weak. Discuss the items you disagree on, clarify the "
              "rating instruction, and re-rate before reporting.")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "taglish_human_validation.xlsx")
