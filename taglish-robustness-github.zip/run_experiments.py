#!/usr/bin/env python3
"""
run_experiments.py
==================
Runs ALL experiments of the paper
  "A Perturbation-Based Framework for Evaluating the Robustness of Text
   Classifiers to Taglish Spelling Variation in Filipino Hate Speech Detection"
and writes the numbers straight into LaTeX table rows.

Needs taglish_robustness.py in the same folder (the perturbation framework).

Models (choose with --models, comma-separated):
  svm      TF-IDF word+char SVM, plus ablations SVM-W (word) and SVM-C (char)
  xlmr     XLM-RoBERTa base, fine-tuned          (GPU recommended)
  robtl    RoBERTa-Tagalog base, fine-tuned      (GPU recommended)
  llm      Qwen2.5-7B-Instruct, zero-shot and 5-shot (GPU required)
  aug      perturbation-augmented training for xlmr and robtl (GPU)

Typical use on Google Colab (T4 GPU):
  python run_experiments.py --models svm                    # ~2 min, CPU is fine
  python run_experiments.py --models xlmr,robtl,aug --seeds 3
  python run_experiments.py --models llm --llm-n 1000
  python run_experiments.py --report                        # build tables + figure

Every run ADDS its results to outputs/results.json, so you can run the models
in separate sessions. --report reads that file and writes:
  outputs/tables.tex            LaTeX rows for every table in the paper
  outputs/robustness_curve.png  figure for the paper (fits 118 mm width)
  outputs/report.txt            plain-text summary, incl. hypothesis tests H1-H3
"""

import argparse
import json
import os
import random
import sys
import time

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import taglish_robustness as tr  # noqa: E402

SEED = tr.SEED
MAIN_RATE = 0.3
CURVE_RATES = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
SET_ORDER = ["CLEAN", "P1_vowel_drop", "P2_abbreviation", "P3_leetspeak",
             "P4_elongation", "P5_funcword", "P6_jejemon", "MIX_all"]
SET_LABEL = {"CLEAN": "Clean", "P1_vowel_drop": "$T_1$", "P2_abbreviation": "$T_2$",
             "P3_leetspeak": "$T_3$", "P4_elongation": "$T_4$",
             "P5_funcword": "$T_5$", "P6_jejemon": "$T_6$", "MIX_all": "Mixed"}

HF_MODELS = {"xlmr": "xlm-roberta-base",
             "robtl": "jcblaise/roberta-tagalog-base"}
LLM_ID = "Qwen/Qwen2.5-7B-Instruct"


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------

def load_splits(args):
    if args.demo:
        return tr.demo_data()
    if args.local_dir:
        return tr.load_from_local(args.local_dir)
    from datasets import load_dataset
    errors = []
    for repo in ["jcblaise/hatespeech_filipino", "legacy-datasets/hate_speech_filipino"]:
        try:
            try:
                ds = load_dataset(repo)
            except Exception:
                ds = load_dataset(repo, trust_remote_code=True)
            splits = {}
            for name in ds.keys():
                key = "valid" if name.startswith("valid") else name
                df = ds[name].to_pandas()
                if "text" not in df.columns:
                    df = df.rename(columns={df.columns[0]: "text"})
                splits[key] = df[["text", "label"]]
            if {"train", "valid", "test"} <= set(splits):
                print(f"Loaded dataset from Hugging Face: {repo}")
                return splits
        except Exception as e:  # try the next mirror
            errors.append(f"{repo}: {e}")
    sys.exit("Could not download the dataset:\n  " + "\n  ".join(errors) +
             "\nDownload the CSV files manually and use --local-dir.")


def prepare(args):
    splits = load_splits(args)
    report = tr.check_data(splits, demo=args.demo)
    overlap = report["train_test_overlap"]["ratio_of_test"]
    if overlap > 0.5 and not args.demo:
        sys.exit("Test split overlaps train (old loading bug). Stop: fix the data first.")
    test = splits["test"].reset_index(drop=True)
    main_sets, main_stats = tr.build_perturbed_sets(test, MAIN_RATE)
    test_sets = {"CLEAN": test, **main_sets}
    curve_sets = {}
    for r in CURVE_RATES[1:]:
        s, _ = tr.build_perturbed_sets(test, r)
        curve_sets[f"MIX_r{r}"] = s["MIX_all"]
    # token statistics for Proposition 2
    lens = [len(w) for t in test["text"] for w in t.split() if tr.eligible(w)]
    tok_stats = {"median_eligible_token_length": float(np.median(lens)) if lens else 0.0,
                 "n_eligible_tokens": len(lens)}
    meta = {"data": report, "perturbation_stats_r0.3": main_stats, "token_stats": tok_stats}
    return splits, test_sets, curve_sets, meta


# ---------------------------------------------------------------------------
# results store
# ---------------------------------------------------------------------------

def load_store(path):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {"meta": {}, "models": {}}


def save_store(store, path):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(store, f, ensure_ascii=False)
    os.replace(tmp, path)


def record(store, model_name, seed, preds_by_set, y_by_set, extra=None):
    """Save predictions (as lists) so that every metric can be recomputed later."""
    m = store["models"].setdefault(model_name, {"runs": {}})
    m["runs"][str(seed)] = {"preds": {k: list(map(int, v)) for k, v in preds_by_set.items()},
                            "y": {k: list(map(int, v)) for k, v in y_by_set.items()},
                            "extra": extra or {}}


# ---------------------------------------------------------------------------
# SVM family
# ---------------------------------------------------------------------------

def svm_pipeline(kind):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.pipeline import FeatureUnion, Pipeline
    from sklearn.svm import LinearSVC
    word = ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True))
    char = ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2,
                                    sublinear_tf=True))
    feats = {"both": [word, char], "word": [word], "char": [char]}[kind]
    return Pipeline([("feats", FeatureUnion(feats)),
                     ("clf", LinearSVC(C=1.0, random_state=SEED))])


def run_svm(splits, test_sets, curve_sets, store):
    all_sets = {**test_sets, **curve_sets}
    y = test_sets["CLEAN"]["label"].to_numpy()
    for name, kind in [("SVM", "both"), ("SVM-W", "word"), ("SVM-C", "char")]:
        t0 = time.time()
        model = svm_pipeline(kind)
        model.fit(splits["train"]["text"], splits["train"]["label"])
        preds = {k: model.predict(df["text"]) for k, df in all_sets.items()}
        record(store, name, 0, preds, {k: y for k in preds},
               {"train_seconds": round(time.time() - t0, 1)})
        print(f"  {name}: done in {time.time() - t0:.1f}s")


# ---------------------------------------------------------------------------
# fine-tuned transformers
# ---------------------------------------------------------------------------

def augmented_train(train_df):
    """Training set + one perturbed copy (mixed family, r=0.3, unseen seed)."""
    rng = random.Random(f"{SEED}-train-augmentation")
    funcs = list(tr.PERTURBATIONS.values())
    pert = [tr.perturb_text(t, funcs, MAIN_RATE, rng)[0] for t in train_df["text"]]
    aug = train_df.copy()
    aug["text"] = pert
    return pd.concat([train_df, aug], ignore_index=True)


def make_training_args(**kw):
    """Build TrainingArguments across transformers versions (option names changed)."""
    import inspect
    from transformers import TrainingArguments
    params = inspect.signature(TrainingArguments.__init__).parameters
    if "eval_strategy" not in params and "evaluation_strategy" in params:
        kw["evaluation_strategy"] = kw.pop("eval_strategy")
    dropped = [k for k in kw if k not in params]
    for k in dropped:
        kw.pop(k)
    if dropped:
        print(f"  (TrainingArguments: ignoring unsupported options {dropped})")
    return TrainingArguments(**kw)


def run_transformer(model_key, model_id, splits, test_sets, curve_sets, store, args,
                    augment=False):
    import torch
    from datasets import Dataset
    from sklearn.metrics import f1_score
    from transformers import (AutoModelForSequenceClassification, AutoTokenizer,
                              DataCollatorWithPadding, Trainer, TrainingArguments,
                              set_seed)

    name = {"xlmr": "XLM-R", "robtl": "RoBERTa-TL"}.get(model_key, model_key)
    if augment:
        name += "+Aug"
    train_df = augmented_train(splits["train"]) if augment else splits["train"]
    tok = AutoTokenizer.from_pretrained(model_id)

    def enc(df):
        ds = Dataset.from_pandas(df[["text", "label"]].reset_index(drop=True))
        return ds.map(lambda b: tok(b["text"], truncation=True, max_length=args.max_len),
                      batched=True, remove_columns=["text"])

    train_ds, valid_ds = enc(train_df), enc(splits["valid"])
    all_sets = {**test_sets, **curve_sets}
    enc_sets = {k: enc(df) for k, df in all_sets.items()}
    y = test_sets["CLEAN"]["label"].to_numpy()

    def metrics(p):
        return {"macro_f1": f1_score(p.label_ids, p.predictions.argmax(-1), average="macro")}

    for seed in range(args.seeds):
        if str(seed) in store["models"].get(name, {}).get("runs", {}):
            print(f"  {name} seed {seed}: already in results, skipping")
            continue
        set_seed(SEED + seed)
        t0 = time.time()
        model = AutoModelForSequenceClassification.from_pretrained(model_id, num_labels=2)
        out_dir = os.path.join(args.work, f"{name}_s{seed}")
        targs = make_training_args(
            output_dir=out_dir, num_train_epochs=args.epochs,
            learning_rate=args.lr, per_device_train_batch_size=args.batch,
            per_device_eval_batch_size=args.batch * 2, weight_decay=0.01,
            warmup_steps=max(1, int(0.1 * args.epochs * len(train_ds) / args.batch)),
            eval_strategy="epoch", save_strategy="epoch",
            load_best_model_at_end=True, metric_for_best_model="macro_f1",
            save_total_limit=1, fp16=torch.cuda.is_available(),
            report_to="none", seed=SEED + seed, logging_steps=50)
        trainer = Trainer(model=model, args=targs, train_dataset=train_ds,
                          eval_dataset=valid_ds, data_collator=DataCollatorWithPadding(tok),
                          compute_metrics=metrics)
        trainer.train()
        preds = {k: trainer.predict(ds).predictions.argmax(-1) for k, ds in enc_sets.items()}
        record(store, name, seed, preds, {k: y for k in preds},
               {"train_seconds": round(time.time() - t0, 1), "model_id": model_id})
        save_store(store, args.store)
        print(f"  {name} seed {seed}: clean macro-F1 = "
              f"{f1_score(y, preds['CLEAN'], average='macro'):.4f} "
              f"({time.time() - t0:.0f}s)")
        del model, trainer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


# ---------------------------------------------------------------------------
# instruction-tuned LLM (zero-shot / 5-shot)
# ---------------------------------------------------------------------------

LLM_SYSTEM = ("You are a content moderator for Filipino social media. Tweets may be in "
              "Filipino, English or Taglish, with informal spelling.")
LLM_TASK = ("Decide whether the tweet is hate speech. Answer with one letter only: "
            "A if it is hate speech, B if it is not.")


def stratified_indices(y, n, seed):
    if n <= 0 or n >= len(y):
        return np.arange(len(y))
    rng = np.random.RandomState(seed)
    idx = []
    for c in np.unique(y):
        ci = np.where(y == c)[0]
        k = int(round(n * len(ci) / len(y)))
        idx.extend(rng.choice(ci, size=min(k, len(ci)), replace=False))
    return np.sort(np.array(idx))


def run_llm(splits, test_sets, curve_sets, store, args):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    llm_id = args.model_override or LLM_ID
    if not torch.cuda.is_available() and not args.model_override:
        sys.exit("The LLM experiment needs a GPU (Colab: Runtime > Change runtime type > T4).")
    tok = AutoTokenizer.from_pretrained(llm_id)
    tok.padding_side = "left"
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    kw = {}
    if torch.cuda.is_available():
        kw = {"device_map": "auto", "dtype": torch.float16}
        try:
            import bitsandbytes  # noqa: F401
            from transformers import BitsAndBytesConfig
            kw["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
        except Exception:
            print("bitsandbytes not available: loading in fp16 (needs ~16 GB GPU memory)")
    try:
        model = AutoModelForCausalLM.from_pretrained(llm_id, **kw).eval()
    except TypeError:  # older transformers use torch_dtype
        if "dtype" in kw:
            kw["torch_dtype"] = kw.pop("dtype")
        model = AutoModelForCausalLM.from_pretrained(llm_id, **kw).eval()

    ids_a = tok.encode("A", add_special_tokens=False)[0]
    ids_b = tok.encode("B", add_special_tokens=False)[0]

    # 5 fixed few-shot examples from the training set (3 non-hate, 2 hate)
    tr_df = splits["train"]
    rng = np.random.RandomState(SEED)
    shots = pd.concat([tr_df[tr_df.label == 0].sample(3, random_state=rng),
                       tr_df[tr_df.label == 1].sample(2, random_state=rng)]
                      ).sample(frac=1, random_state=rng)

    def prompt(text, few):
        msgs = [{"role": "system", "content": LLM_SYSTEM}]
        if few:
            for t, lab in zip(shots["text"], shots["label"]):
                msgs.append({"role": "user", "content": f"{LLM_TASK}\nTweet: {t}"})
                msgs.append({"role": "assistant", "content": "A" if lab == 1 else "B"})
        msgs.append({"role": "user", "content": f"{LLM_TASK}\nTweet: {text}"})
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)

    @torch.no_grad()
    def classify(texts, few):
        out = []
        for i in range(0, len(texts), args.llm_batch):
            batch = [prompt(t, few) for t in texts[i:i + args.llm_batch]]
            encd = tok(batch, return_tensors="pt", padding=True).to(model.device)
            logits = model(**encd).logits[:, -1, :]
            out.extend((logits[:, ids_a] > logits[:, ids_b]).long().tolist())
        return np.array(out)

    y_full = test_sets["CLEAN"]["label"].to_numpy()
    idx = stratified_indices(y_full, args.llm_n, SEED)
    y = y_full[idx]
    all_sets = {**test_sets, **curve_sets}
    for few, name in [(False, "LLM-0"), (True, "LLM-5")]:
        if "0" in store["models"].get(name, {}).get("runs", {}):
            print(f"  {name}: already in results, skipping")
            continue
        t0 = time.time()
        preds = {}
        for k, df in all_sets.items():
            preds[k] = classify(df["text"].iloc[idx].tolist(), few)
            print(f"    {name} {k}: done")
        record(store, name, 0, preds, {k: y for k in preds},
               {"n_test_subsample": int(len(idx)),
                "seconds": round(time.time() - t0, 1), "model": llm_id,
                "few_shot_examples": shots[["text", "label"]].to_dict("records") if few else []})
        save_store(store, args.store)


# ---------------------------------------------------------------------------
# metrics, significance, report
# ---------------------------------------------------------------------------

def holm(pvals):
    """Holm-Bonferroni adjusted p-values (same order as input)."""
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def model_metrics(run):
    from sklearn.metrics import f1_score
    y = np.array(run["y"]["CLEAN"])
    pc = np.array(run["preds"]["CLEAN"])
    f1c = f1_score(y, pc, average="macro")
    rows, pvals = {}, []
    for k in run["preds"]:
        p = np.array(run["preds"][k])
        f1 = f1_score(y, p, average="macro")
        b, c, pv = tr.mcnemar_exact(y, pc, p)
        rows[k] = {"f1": f1, "RD": 100 * (f1c - f1) / f1c if f1c > 0 else 0.0,
                   "FR": 100 * float(np.mean(p != pc)), "b": b, "c": c, "p": pv}
    main = [k for k in SET_ORDER[1:] if k in rows]
    for k, pa in zip(main, holm([rows[k]["p"] for k in main])):
        rows[k]["p_holm"] = float(pa)
    rows["CLEAN"]["p_holm"] = 1.0
    # normalised robustness area over the mixed-family curve
    g = [1.0]
    for r in CURVE_RATES[1:]:
        key = f"MIX_r{r}"
        g.append(rows[key]["f1"] / f1c if key in rows and f1c > 0 else np.nan)
    ra = sum((CURVE_RATES[j] - CURVE_RATES[j - 1]) * (g[j - 1] + g[j]) / 2
             for j in range(1, len(CURVE_RATES))) / CURVE_RATES[-1]
    return rows, g, float(ra)


def summarise(store):
    """Mean/std over seeds; significance = Holm p<0.05 in every seed."""
    summary = {}
    for name, m in store["models"].items():
        per_seed = [model_metrics(r) for r in m["runs"].values()]
        rows = {}
        for k in per_seed[0][0]:
            vals = {s: [ps[0][k][s] for ps in per_seed] for s in ("f1", "RD", "FR")}
            rows[k] = {s: (float(np.mean(v)), float(np.std(v))) for s, v in vals.items()}
            rows[k]["sig"] = all(ps[0][k].get("p_holm", 1.0) < 0.05 for ps in per_seed)
        curve = np.nanmean([ps[1] for ps in per_seed], axis=0).tolist()
        ra = [ps[2] for ps in per_seed]
        summary[name] = {"rows": rows, "curve": curve,
                         "RA": (float(np.mean(ra)), float(np.std(ra))),
                         "n_seeds": len(per_seed),
                         "n_test": len(next(iter(m["runs"].values()))["y"]["CLEAN"])}
    return summary


MODEL_ORDER = ["SVM", "SVM-W", "SVM-C", "XLM-R", "RoBERTa-TL", "XLM-R+Aug",
               "RoBERTa-TL+Aug", "LLM-0", "LLM-5"]
F1_TABLE_MODELS = [("SVM", "SVM"), ("XLM-R", "XLM-R"), ("RoBERTa-TL", "RoB-TL"),
                   ("LLM-0", "LLM-0"), ("LLM-5", "LLM-5")]


def fmt(mean_std, n_seeds, digits=3, sig=False):
    m, s = mean_std
    txt = f"{m:.{digits}f}"
    if n_seeds > 1:
        txt += f"\\,$\\pm$\\,{s:.{digits}f}"
    return txt + ("$^{*}$" if sig else "")


def write_report(store, out_dir):
    summary = summarise(store)
    meta = store.get("meta", {})
    lines_tex, lines_txt = [], []

    # Table: dataset
    d = meta.get("data", {})
    if d:
        lines_tex.append("% ---- Table tab:data (rows) ----")
        for k, lab in [("train", "Train"), ("valid", "Validation"), ("test", "Test")]:
            cc = d[k]["class_counts"]
            lines_tex.append(f"{lab} & {d[k]['rows']:,} & {cc.get('1', cc.get(1, 0)):,} & "
                             f"{cc.get('0', cc.get(0, 0)):,}\\\\".replace(",", "{,}"))
        lines_tex.append(f"% train/test identical texts: {d['train_test_overlap']['count']}")

    # Table: perturbation statistics
    ps = meta.get("perturbation_stats_r0.3", {})
    if ps:
        n_test = d.get("test", {}).get("rows", 1) if d else 1
        names = {"P1_vowel_drop": "$T_1$ Vowel dropping", "P2_abbreviation": "$T_2$ Abbreviation",
                 "P3_leetspeak": "$T_3$ Number substitution", "P4_elongation": "$T_4$ Elongation",
                 "P5_funcword": "$T_5$ Function words", "P6_jejemon": "$T_6$ Jejemon",
                 "MIX_all": "Mixed"}
        lines_tex.append("% ---- Table tab:pstats (rows) ----")
        for k, lab in names.items():
            s = ps[k]
            lines_tex.append(f"{lab} & {100 * s['token_change_rate']:.1f} & "
                             f"{100 * s['sentences_changed'] / n_test:.1f}\\\\")
    ts = meta.get("token_stats", {})
    if ts:
        L = ts["median_eligible_token_length"]
        lines_txt.append(f"Median eligible token length L = {L:g}; "
                         f"Prop. 2 bound for T4, n=3: at least {max(0, L - 2 * 3 + 1):g} "
                         f"of {max(0, L - 3 + 1):g} trigrams preserved.")

    # Table: macro-F1
    lines_tex.append("% ---- Table tab:f1 (rows) ----")
    for k in SET_ORDER:
        cells = []
        for mname, _ in F1_TABLE_MODELS:
            sm = summary.get(mname)
            if sm and k in sm["rows"]:
                r = sm["rows"][k]
                cells.append(fmt(r["f1"], sm["n_seeds"], sig=(k != "CLEAN" and r["sig"])))
            else:
                cells.append("--")
        lines_tex.append(f"{SET_LABEL[k]} & " + " & ".join(cells) + "\\\\")

    # Table: RD / FR / RA
    lines_tex.append("% ---- Table tab:rd (rows): mixed set ----")
    for mname in MODEL_ORDER:
        sm = summary.get(mname)
        if not sm:
            continue
        r = sm["rows"]["MIX_all"]
        lines_tex.append(f"{mname} & {fmt(r['RD'], sm['n_seeds'], 1)} & "
                         f"{fmt(r['FR'], sm['n_seeds'], 1)} & {fmt(sm['RA'], sm['n_seeds'], 3)}\\\\")

    # Per-perturbation RD for hypotheses
    lines_txt.append("\nRelative degradation RD (%) per perturbation, r = 0.3:")
    header = "model".ljust(16) + "".join(k.split("_")[0].rjust(8) for k in SET_ORDER[1:])
    lines_txt.append(header)
    for mname in MODEL_ORDER:
        sm = summary.get(mname)
        if not sm:
            continue
        lines_txt.append(mname.ljust(16) + "".join(
            f"{sm['rows'][k]['RD'][0]:8.1f}" for k in SET_ORDER[1:]))

    def rd(m, k):
        return summary[m]["rows"][k]["RD"][0]

    if "SVM-W" in summary and "SVM-C" in summary:
        h1 = {k: rd("SVM-W", k) - rd("SVM-C", k) for k in
              ["P1_vowel_drop", "P3_leetspeak", "P4_elongation", "P6_jejemon"]}
        h2 = {k: rd("SVM-W", k) - rd("SVM-C", k) for k in ["P2_abbreviation", "P5_funcword"]}
        lines_txt.append("\nH1 (RD of SVM-W minus SVM-C; positive = char features more robust): " +
                         ", ".join(f"{k.split('_')[0]} {v:+.1f}" for k, v in h1.items()) +
                         f" -> {'SUPPORTED' if all(v > 0 for v in h1.values()) else 'NOT fully supported'}")
        lines_txt.append("H2 (same difference under T2, T5; expected small): " +
                         ", ".join(f"{k.split('_')[0]} {v:+.1f}" for k, v in h2.items()))
    for m in ["XLM-R", "RoBERTa-TL"]:
        if m in summary:
            ok = min(rd(m, "P3_leetspeak"), rd(m, "P6_jejemon")) > rd(m, "P4_elongation")
            lines_txt.append(f"H3 {m}: RD T3={rd(m, 'P3_leetspeak'):.1f}, "
                             f"T6={rd(m, 'P6_jejemon'):.1f}, T4={rd(m, 'P4_elongation'):.1f} -> "
                             f"{'SUPPORTED' if ok else 'NOT supported'}")
    for base in ["XLM-R", "RoBERTa-TL"]:
        if base in summary and base + "+Aug" in summary:
            a, b = summary[base], summary[base + "+Aug"]
            lines_txt.append(
                f"Mitigation {base}: clean F1 {a['rows']['CLEAN']['f1'][0]:.3f} -> "
                f"{b['rows']['CLEAN']['f1'][0]:.3f}; mixed RD {a['rows']['MIX_all']['RD'][0]:.1f}% -> "
                f"{b['rows']['MIX_all']['RD'][0]:.1f}%")
    for m in ["LLM-0", "LLM-5"]:
        if m in summary:
            lines_txt.append(f"Note: {m} evaluated on a stratified subsample of "
                             f"{summary[m]['n_test']} test tweets (state this in the paper).")

    with open(os.path.join(out_dir, "tables.tex"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines_tex) + "\n")
    with open(os.path.join(out_dir, "report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines_txt) + "\n")
    print("\n".join(lines_tex))
    print("\n".join(lines_txt))

    # robustness curve figure, sized for the CSJM text width (118 mm)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(4.6, 2.8), dpi=300)
        markers = "osD^v<>ph"
        for i, mname in enumerate(MODEL_ORDER):
            if mname in summary:
                ax.plot(CURVE_RATES, summary[mname]["curve"], marker=markers[i % 9],
                        markersize=3, linewidth=1, label=mname)
        ax.set_xlabel("perturbation rate $r$ (mixed family)")
        ax.set_ylabel("$F(f,D'_r)\\,/\\,F(f,D)$")
        ax.grid(alpha=0.3, linewidth=0.5)
        ax.legend(fontsize=6, ncol=2, frameon=False)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "robustness_curve.png"))
        print(f"\nFigure saved: {os.path.join(out_dir, 'robustness_curve.png')}")
    except Exception as e:
        print(f"(figure skipped: {e})")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--models", default="", help="svm,xlmr,robtl,aug,llm")
    ap.add_argument("--report", action="store_true", help="build tables and figure")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--local-dir")
    ap.add_argument("--demo", action="store_true", help="tiny built-in sample (testing only)")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--max-len", type=int, default=128)
    ap.add_argument("--llm-n", type=int, default=1000,
                    help="stratified test subsample for the LLM (0 = full test set)")
    ap.add_argument("--llm-batch", type=int, default=8)
    ap.add_argument("--model-override", help=argparse.SUPPRESS)  # for testing with a tiny model
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    args.store = os.path.join(args.out, "results.json")
    args.work = os.path.join(args.out, "checkpoints")
    store = load_store(args.store)
    models = [m.strip() for m in args.models.split(",") if m.strip()]

    if models:
        random.seed(SEED)
        np.random.seed(SEED)
        splits, test_sets, curve_sets, meta = prepare(args)
        store["meta"] = meta
        for m in models:
            print(f"\n=== {m} ===")
            if m == "svm":
                run_svm(splits, test_sets, curve_sets, store)
            elif m in HF_MODELS:
                run_transformer(m, args.model_override or HF_MODELS[m], splits, test_sets,
                                curve_sets, store, args)
            elif m == "aug":
                for k in ["xlmr", "robtl"]:
                    run_transformer(k, args.model_override or HF_MODELS[k], splits, test_sets,
                                    curve_sets, store, args, augment=True)
            elif m == "llm":
                run_llm(splits, test_sets, curve_sets, store, args)
            else:
                sys.exit(f"Unknown model '{m}'")
            save_store(store, args.store)
        print(f"\nResults saved to {args.store}")

    if args.report or models:
        if store["models"]:
            print("\n=== REPORT ===")
            write_report(store, args.out)
        else:
            print("No results yet. Run with --models first.")


if __name__ == "__main__":
    main()
