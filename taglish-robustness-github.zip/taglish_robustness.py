#!/usr/bin/env python3
"""
taglish_robustness.py
=====================
Step 1 of the study:
  "A Perturbation-Based Framework for Evaluating the Robustness of Transformer
   and LLM Classifiers to Taglish Spelling Variation in Filipino Hate Speech
   Detection"

What this script does
---------------------
1. Loads the Hate Speech Filipino dataset (Cabasag et al., 2019) from Hugging Face
   (or from local CSV files if you downloaded them manually).
2. Checks data quality: split sizes, class balance, empty texts, duplicates,
   and train/test overlap (the old HF bug where test == train).
3. Applies six Taglish perturbation types (P1-P6) to the TEST set only,
   at a controllable rate, with a fixed random seed (reproducible).
4. Trains a TF-IDF + Linear SVM baseline on CLEAN training data and evaluates it
   on the clean test set and on every perturbed test set.
5. Reports macro-F1, Relative Degradation (RD), and McNemar's test (clean vs.
   perturbed predictions), and saves everything to ./outputs/.

Usage
-----
    pip install "datasets<4.0" scikit-learn pandas scipy
    python taglish_robustness.py                 # Hugging Face download
    python taglish_robustness.py --local-dir data # use train.csv/valid.csv/test.csv
    python taglish_robustness.py --rate 0.3      # perturb 30% of eligible tokens
    python taglish_robustness.py --demo          # tiny built-in sample, no download

Local CSV format (if HF download fails): columns `text,label`, files named
train.csv, valid.csv (or validation.csv), test.csv.
"""

import argparse
import json
import os
import random
import re
import sys

import numpy as np
import pandas as pd

SEED = 42

# ---------------------------------------------------------------------------
# 1. DATA LOADING
# ---------------------------------------------------------------------------

def load_from_hf():
    from datasets import load_dataset
    ds = load_dataset("legacy-datasets/hate_speech_filipino", trust_remote_code=True)
    splits = {}
    for name in ds.keys():
        key = "valid" if name.startswith("valid") else name
        splits[key] = ds[name].to_pandas()[["text", "label"]]
    return splits


def load_from_local(folder):
    splits = {}
    for key, names in {"train": ["train.csv"],
                       "valid": ["valid.csv", "validation.csv"],
                       "test": ["test.csv"]}.items():
        for n in names:
            p = os.path.join(folder, n)
            if os.path.exists(p):
                splits[key] = pd.read_csv(p)[["text", "label"]]
                break
        if key not in splits:
            sys.exit(f"Missing {names[0]} in {folder}")
    return splits


def demo_data():
    """Tiny synthetic sample ONLY for testing that the code runs."""
    hate = ["ang bobo talaga ni kandidato hindi siya dapat manalo",
            "wala kang kwenta sige umalis ka na dito",
            "kasi naman ang tanga ng mga taga suporta niya",
            "hindi ko talaga gusto yung mga sinungaling na yan"]
    ok = ["sana maging maayos ang eleksyon ngayong taon",
          "salamat po sa lahat ng tumulong sa amin",
          "ang ganda ng debate kagabi naman diba",
          "boboto ako para sa kinabukasan ng bansa"]
    rows = [(t, 1) for t in hate] + [(t, 0) for t in ok]
    df = pd.DataFrame(rows * 25, columns=["text", "label"]).sample(frac=1, random_state=SEED)
    n = len(df)
    return {"train": df.iloc[: int(.6 * n)].reset_index(drop=True),
            "valid": df.iloc[int(.6 * n): int(.8 * n)].reset_index(drop=True),
            "test": df.iloc[int(.8 * n):].reset_index(drop=True)}


# ---------------------------------------------------------------------------
# 2. DATA QUALITY CHECKS
# ---------------------------------------------------------------------------

def check_data(splits, demo=False):
    report = {}
    print("\n=== DATA CHECK ===")
    for k, df in splits.items():
        df["text"] = df["text"].fillna("").astype(str)
        counts = df["label"].value_counts().sort_index().to_dict()
        report[k] = {"rows": len(df),
                     "class_counts": {int(a): int(b) for a, b in counts.items()},
                     "empty_texts": int((df["text"].str.strip() == "").sum()),
                     "duplicate_texts": int(df["text"].duplicated().sum())}
        print(f"{k:6s}: {len(df):6d} rows | classes {report[k]['class_counts']} | "
              f"empty {report[k]['empty_texts']} | duplicates {report[k]['duplicate_texts']}")

    overlap = len(set(splits["train"]["text"]) & set(splits["test"]["text"]))
    ratio = overlap / max(1, len(splits["test"]))
    report["train_test_overlap"] = {"count": overlap, "ratio_of_test": round(ratio, 4)}
    print(f"train/test overlap: {overlap} texts ({ratio:.1%} of test)")
    if not demo:
        if ratio > 0.5:
            print("!! WARNING: test set looks identical to train (old HF bug). "
                  "Re-download the fixed version before running experiments.")
        if len(splits["test"]) != 4232:
            print(f"!! NOTE: expected 4,232 test rows, found {len(splits['test'])}.")
    return report


# ---------------------------------------------------------------------------
# 3. TAGLISH PERTURBATION FRAMEWORK
# ---------------------------------------------------------------------------
# Each perturbation T_k maps a token w to w' while preserving meaning for a
# Filipino reader. A sentence x = (w_1..w_n) is perturbed by applying T_k to
# each ELIGIBLE token independently with probability `rate` (Bernoulli).
# Eligible = alphabetic word, not a URL/@mention/#hashtag, length >= 2.

PROTECTED = re.compile(r"^(https?://|www\.|@|#)")
TOKEN_RE = re.compile(r"\S+")
VOWELS = set("aeiouAEIOU")

# P2: common Filipino/Taglish social-media abbreviations (texting style).
ABBREV = {
    "ako": "aq", "ikaw": "ikw", "kasi": "kc", "naman": "nmn", "talaga": "tlga",
    "lang": "lng", "dito": "d2", "sige": "cge", "hindi": "hnd", "wala": "wla",
    "yung": "ung", "ngayon": "ngaun", "siya": "cya", "sila": "cla", "kayo": "kau",
    "po": "pu", "pa": "p", "na": "n", "mga": "mga", "ganun": "gnun",
    "bakit": "bkt", "paano": "pano", "sana": "sna", "salamat": "slmt",
    "you": "u", "are": "r", "your": "ur", "because": "bcoz", "please": "pls",
    "people": "ppl", "love": "luv", "what": "wat", "thanks": "thx",
}

# P5: confusable function-word pairs common in informal Filipino writing.
FUNCWORD = {"ng": "nang", "nang": "ng", "din": "rin", "rin": "din",
            "daw": "raw", "raw": "daw", "doon": "dun", "dun": "doon",
            "ito": "eto", "iyan": "yan", "iyon": "yun"}

LEET = {"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7"}


def p1_vowel_drop(w, rng):
    """P1 Vowel dropping: keep first letter, drop interior vowels (bansa -> bnsa, para -> pra)."""
    if len(w) < 4:
        return w
    core = w[0] + "".join(c for c in w[1:-1] if c not in VOWELS) + w[-1]
    return core if len(core) >= 2 else w


def p2_abbrev(w, rng):
    """P2 Texting abbreviation via lexicon (kasi -> kc, ikaw -> ikw)."""
    low = w.lower()
    return ABBREV.get(low, w)


def p3_leet(w, rng):
    """P3 Number-for-letter substitution, ~50% of mappable characters (bobo -> b0b0)."""
    out = [LEET[c.lower()] if c.lower() in LEET and rng.random() < 0.5 else c for c in w]
    return "".join(out)


def p4_elongate(w, rng):
    """P4 Character elongation: repeat the last vowel 2-4 extra times (grabe -> grabeee)."""
    idx = [i for i, c in enumerate(w) if c in VOWELS]
    if not idx:
        return w
    i = idx[-1]
    return w[: i + 1] + w[i] * rng.randint(2, 4) + w[i + 1:]


def p5_funcword(w, rng):
    """P5 Function-word confusion (ng <-> nang, din <-> rin)."""
    return FUNCWORD.get(w.lower(), w)


def p6_jejemon(w, rng):
    """P6 'Jejemon' style: alternating case + optional h-insertion after vowels (po -> PoH)."""
    chars = []
    for j, c in enumerate(w):
        c = c.upper() if j % 2 == 0 else c.lower()
        chars.append(c)
        if c.lower() in "aeiou" and rng.random() < 0.3:
            chars.append("h")
    return "".join(chars)


PERTURBATIONS = {
    "P1_vowel_drop": p1_vowel_drop,
    "P2_abbreviation": p2_abbrev,
    "P3_leetspeak": p3_leet,
    "P4_elongation": p4_elongate,
    "P5_funcword": p5_funcword,
    "P6_jejemon": p6_jejemon,
}


def eligible(tok):
    return (not PROTECTED.match(tok)) and tok.isalpha() and len(tok) >= 2


def perturb_text(text, funcs, rate, rng):
    """Apply one randomly chosen function from `funcs` to each eligible token w.p. `rate`.
    Returns (perturbed_text, n_eligible, n_changed)."""
    n_elig = n_changed = 0

    def repl(m):
        nonlocal n_elig, n_changed
        tok = m.group(0)
        if not eligible(tok):
            return tok
        n_elig += 1
        if rng.random() >= rate:
            return tok
        new = rng.choice(funcs)(tok, rng)
        if new != tok:
            n_changed += 1
        return new

    return TOKEN_RE.sub(repl, text), n_elig, n_changed


def build_perturbed_sets(test_df, rate, seed=SEED):
    sets, stats = {}, {}
    configs = {k: [f] for k, f in PERTURBATIONS.items()}
    configs["MIX_all"] = list(PERTURBATIONS.values())
    for name, funcs in configs.items():
        rng = random.Random(f"{seed}-{name}")
        out, elig, chg = [], 0, 0
        for t in test_df["text"]:
            p, e, c = perturb_text(t, funcs, rate, rng)
            out.append(p); elig += e; chg += c
        df = test_df.copy()
        df["text"] = out
        sets[name] = df
        stats[name] = {"eligible_tokens": elig, "changed_tokens": chg,
                       "token_change_rate": round(chg / max(1, elig), 4),
                       "sentences_changed": int((df["text"] != test_df["text"]).sum())}
    return sets, stats


# ---------------------------------------------------------------------------
# 4. BASELINE MODEL + ROBUSTNESS METRICS
# ---------------------------------------------------------------------------

def mcnemar_exact(y, p_clean, p_pert):
    """Exact McNemar test on correctness of clean vs perturbed predictions."""
    c_clean = p_clean == y
    c_pert = p_pert == y
    b = int(np.sum(c_clean & ~c_pert))   # correct -> wrong
    c = int(np.sum(~c_clean & c_pert))   # wrong -> correct
    n = b + c
    if n == 0:
        return b, c, 1.0
    try:
        from scipy.stats import binomtest
        pval = binomtest(min(b, c), n, 0.5, alternative="two-sided").pvalue
    except ImportError:  # fallback normal approximation with continuity correction
        from math import erf, sqrt
        z = (abs(b - c) - 1) / sqrt(n)
        pval = 2 * (1 - 0.5 * (1 + erf(z / sqrt(2))))
    return b, c, float(pval)


def run_baseline(splits, perturbed):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.pipeline import FeatureUnion, Pipeline
    from sklearn.svm import LinearSVC
    from sklearn.metrics import f1_score, accuracy_score

    model = Pipeline([
        ("feats", FeatureUnion([
            ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2,
                                     sublinear_tf=True)),
        ])),
        ("clf", LinearSVC(C=1.0, random_state=SEED)),
    ])
    model.fit(splits["train"]["text"], splits["train"]["label"])

    y = splits["test"]["label"].to_numpy()
    p_clean = model.predict(splits["test"]["text"])
    f1_clean = f1_score(y, p_clean, average="macro")
    rows = [{"test_set": "CLEAN", "macro_f1": f1_clean,
             "accuracy": accuracy_score(y, p_clean), "RD_percent": 0.0,
             "b_correct_to_wrong": 0, "c_wrong_to_correct": 0, "mcnemar_p": 1.0}]
    preds = {"CLEAN": p_clean}
    for name, df in perturbed.items():
        p = model.predict(df["text"])
        preds[name] = p
        f1 = f1_score(y, p, average="macro")
        b, c, pval = mcnemar_exact(y, p_clean, p)
        rows.append({"test_set": name, "macro_f1": f1,
                     "accuracy": accuracy_score(y, p),
                     "RD_percent": 100 * (f1_clean - f1) / f1_clean,
                     "b_correct_to_wrong": b, "c_wrong_to_correct": c,
                     "mcnemar_p": pval})
    res = pd.DataFrame(rows)
    return res, preds


# ---------------------------------------------------------------------------
# 5. MAIN
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--local-dir", help="folder with train/valid/test CSV files")
    ap.add_argument("--rate", type=float, default=0.3,
                    help="probability of perturbing each eligible token (default 0.3)")
    ap.add_argument("--out", default="outputs", help="output folder")
    ap.add_argument("--demo", action="store_true", help="run on a tiny built-in sample")
    ap.add_argument("--skip-baseline", action="store_true")
    args = ap.parse_args()

    random.seed(SEED); np.random.seed(SEED)
    os.makedirs(args.out, exist_ok=True)

    if args.demo:
        splits = demo_data()
    elif args.local_dir:
        splits = load_from_local(args.local_dir)
    else:
        try:
            splits = load_from_hf()
        except Exception as e:
            sys.exit(f"Hugging Face download failed: {e}\n"
                     "Install with: pip install 'datasets<4.0'  or use --local-dir.")

    data_report = check_data(splits, demo=args.demo)

    print(f"\n=== PERTURBATION (rate = {args.rate}) ===")
    perturbed, pstats = build_perturbed_sets(splits["test"], args.rate)
    for name, s in pstats.items():
        print(f"{name:16s}: {s['token_change_rate']:.1%} of eligible tokens changed, "
              f"{s['sentences_changed']} sentences changed")
        perturbed[name].to_csv(os.path.join(args.out, f"test_{name}.csv"), index=False)
    splits["test"].to_csv(os.path.join(args.out, "test_CLEAN.csv"), index=False)

    # Side-by-side examples for the paper's "Perturbation examples" table
    ex = splits["test"][["text"]].head(5).rename(columns={"text": "original"})
    for name, df in perturbed.items():
        ex[name] = df["text"].head(5).values
    ex.to_csv(os.path.join(args.out, "perturbation_examples.csv"), index=False)
    print("\nExample (first test tweet):")
    for col in ex.columns:
        print(f"  {col:16s}: {ex.iloc[0][col]}")

    summary = {"seed": SEED, "rate": args.rate, "data": data_report,
               "perturbation_stats": pstats}

    if not args.skip_baseline:
        print("\n=== BASELINE: TF-IDF (word+char) + Linear SVM ===")
        res, preds = run_baseline(splits, perturbed)
        res.to_csv(os.path.join(args.out, "baseline_results.csv"), index=False)
        with pd.option_context("display.float_format", "{:.4f}".format,
                               "display.width", 140):
            print(res.to_string(index=False))
        summary["baseline_results"] = res.to_dict(orient="records")

    with open(os.path.join(args.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\nAll outputs saved to ./{args.out}/")


if __name__ == "__main__":
    main()
