# Taglish Robustness

Code for the paper:

> A. A. Dormendo and E. V. Maliberan, "A Perturbation-Based Framework for Evaluating the Robustness of Text Classifiers to Taglish Spelling Variation in Filipino Hate Speech Detection," submitted to *Computer Science Journal of Moldova*.

The framework applies six Taglish spelling perturbations to a test set and measures how much text classifiers change:

| Operator | Spelling habit | Example |
|---|---|---|
| T1 | Vowel dropping | bansa → bnsa |
| T2 | Texting abbreviation | kasi → kc |
| T3 | Number-for-letter substitution | bobo → b0bo |
| T4 | Elongation | grabe → grabeee |
| T5 | Function-word confusion | ng ↔ nang |
| T6 | Jejemon styling | kinabukasan → KiNaBuhKahSaN |

## Files

| File | Purpose |
|---|---|
| `taglish_robustness.py` | The perturbation framework (operators, eligibility rule, perturbation process) and the TF-IDF + SVM baseline |
| `run_experiments.py` | Runs every experiment in the paper and writes the LaTeX tables, report and figure |
| `taglish_experiments_colab.ipynb` | One-click Google Colab notebook for the GPU experiments |
| `compute_agreement.py` | Inter-rater agreement for the human validation (Cohen's kappa, Gwet's AC1) |
| `results/` | Our saved predictions (`results.json`, no tweet text), tables, report and figure |

## Data

We use the Hate Speech Filipino dataset (Cabasag et al., 2019) with the splits released by Cruz and Cheng: 10,000 training, 4,232 validation and 4,232 test tweets. The tweets are **not** redistributed here. Download them from Hugging Face (`jcblaise/hatespeech_filipino`) and save them as:

```
data/train.csv
data/validation.csv
data/test.csv
```

Each file has the columns `text,label` (1 = hate speech, 0 = not).

## Reproducing the results

All randomness uses fixed seeds, so the perturbed test sets are regenerated exactly from the public data.

```bash
pip install "transformers>=4.45" "datasets<4.0" accelerate scikit-learn scipy matplotlib pandas

# SVM baseline and ablations (CPU, about 1 minute)
python run_experiments.py --models svm --local-dir data --out outputs

# Fine-tuned XLM-R and RoBERTa-Tagalog, 3 seeds each (GPU)
python run_experiments.py --models xlmr,robtl --seeds 3 --local-dir data --out outputs

# Perturbation-augmented training (GPU)
python run_experiments.py --models aug --seeds 3 --local-dir data --out outputs

# Tables, hypothesis report and robustness-curve figure
python run_experiments.py --report --out outputs
```

To produce only the perturbed test sets:

```bash
python taglish_robustness.py --local-dir data --rate 0.3 --skip-baseline --out perturbed
```

On Google Colab, open `taglish_experiments_colab.ipynb`, choose a T4 GPU, and run the cells in order.

## Citation

If you use this code, please cite the paper above.

## License

The code is released under the MIT License (see `LICENSE`). The dataset is subject to the terms of its original authors.
